Overview
--------

.. automodule:: uvm.globals
